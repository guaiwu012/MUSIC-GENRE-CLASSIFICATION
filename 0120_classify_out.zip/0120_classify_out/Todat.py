from python_speech_features import mfcc
import scipy.io.wavfile as wav
import numpy as np
import os
import pickle

import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

spectrogram_directory = "spectrogram_plots" # spectrogram figures folder
os.makedirs(spectrogram_directory, exist_ok=True)


directory = "genres_original" # path for training data
f = open("feature.dat", 'wb')
i = 0

for folder in os.listdir(directory):
    i += 1
    if i == 11: # our genre has only 10 types
        break
    for file in os.listdir(os.path.join(directory, folder)):
        file_path = os.path.join(directory, folder, file)
        
        try:
            # if WAV is valid
            with open(file_path, 'rb') as check_file:
                if check_file.read(4) != b'RIFF': # avoid incorrect File Format
                    print(f"Skipping non-WAV file: {file_path}")
                    continue
                
            # read WAV
            (rate, sig) = wav.read(file_path)
            # extract MFCC features:sig rate
            # winlen is the length of the analysis window in seconds
            # DO NOT set big winlen in case running slowly!
            mfcc_feat = mfcc(sig, rate, winlen=0.20, appendEnergy=False)
            covariance = np.cov(np.matrix.transpose(mfcc_feat))
            mean_matrix = mfcc_feat.mean(0)
            feature = (mean_matrix, covariance, i)
            # save feature
            pickle.dump(feature, f)
            # figure
            plt.figure(figsize=(8, 4))
            plt.specgram(sig, NFFT=1024, Fs=rate, cmap='viridis', norm=LogNorm())
            plt.title(f"Spectrogram - {file}")
            plt.xlabel("Time (s)")
            plt.ylabel("Frequency (Hz)")
            plt.colorbar(label="Log Power Spectral Density")
            spectrogram_filename = os.path.join(spectrogram_directory, f"{file}.png")
            plt.savefig(spectrogram_filename)
            plt.close()
            
        
        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

f.close()
print("Done figure & todat")
