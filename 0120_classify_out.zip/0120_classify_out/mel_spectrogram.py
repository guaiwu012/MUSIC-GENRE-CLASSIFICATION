import librosa
from collections import defaultdict
import os
from python_speech_features import mfcc
import scipy.io.wavfile as wav
import numpy as np
from tempfile import TemporaryFile
import pickle
import random 
import operator
import math

# load data
dataset = []
def loadDataset(filename):
    with open(filename, 'rb') as f:
        while True:
            try:
                dataset.append(pickle.load(f))
            except EOFError:
                f.close()
                break

loadDataset("feature.dat")

# compute feature of mel
def compute_mel_spectrogram(file_path):
    y, sr = librosa.load(file_path, sr=None)
    mel_spectrogram = librosa.feature.melspectrogram(y=y, sr=sr)
    return mel_spectrogram

# compute distance
# 1.If the instances are based on original MFCC features, it uses a distance formula involving mean matrix, covariance matrix, and logarithmic determinants. 
# 2.If the instances are based on Mel spectrogram features, it uses the Euclidean distance.
def distance(instance1, instance2):
    if len(instance1) == 3 and len(instance2) == 3:
        # MFCC
        mm1, cm1, _ = instance1
        mm2, cm2, _ = instance2
        try:
            dist = np.trace(np.dot(np.linalg.inv(cm2), cm1)) 
            dist += (np.dot(np.dot((mm2 - mm1).transpose(), np.linalg.inv(cm2)), mm2 - mm1 )) 
            dist += np.log(np.linalg.det(cm2)) - np.log(np.linalg.det(cm1))
            return dist
        except np.linalg.LinAlgError:
            # cases where the covariance matrix is irreversible
            return float('inf')
    elif len(instance1) == 2 and len(instance2) == 2:
        # Mel spectrogram features
        return np.linalg.norm(instance1[0] - instance2[0])
    else:
        raise ValueError("Unsupported instance format")


# get neighbors
def getNeighbors(trainingSet, instance, k):
    distances = []
    for x in range(len(trainingSet)):
        dist = distance(trainingSet[x], instance)
        distances.append((trainingSet[x][2], dist))
    distances.sort(key=lambda x: x[1])
    neighbors = [x[0] for x in distances[:k]]
    return neighbors

# get nearest class
def nearestClass(neighbors):
    classVote = defaultdict(int)
    for response in neighbors: # count the occurrences of each class in the neighbors
        classVote[response] += 1 
    sorter = sorted(classVote.items(), key=lambda x: x[1], reverse=True)
    return sorter[0][0]

# result
results = defaultdict(int)

i = 1
for folder in os.listdir("./musics/wav_genres/"):
    results[i] = folder
    i += 1

file_path = "./waitingfor_identify/metal.00011.wav" # new music waiting for indentify
mel_spectrogram = compute_mel_spectrogram(file_path)

feature = (mel_spectrogram, None, 0)

# predict
pred = nearestClass(getNeighbors(dataset, feature, 5))

print("-"*30)
print("The predict result:")
print(results[pred])
